import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._();
  static Database? _database;

  DatabaseHelper._();

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasePath = await getDatabasesPath();
    final path = join(databasePath, 'my_database.db');

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDatabase,
    );
  }

  Future<void> _createDatabase(Database db, int version) async {
    await db.execute('''
      CREATE TABLE likedP(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        description TEXT,
        imagePath TEXT,
        price REAL
        
      )
    ''');
  }

  static Future<int> insertProduct(ProductSq product) async {
    final db = await instance.database;
    return await db.insert('likedP', product.toMap());
  }

  static Future<List<ProductSq>> getProducts() async {
    final db = await instance.database;
    final List<Map<String, dynamic>> maps = await db.query('likedP');
    return List.generate(maps.length, (index) {
      return ProductSq(
        name: maps[index]['name'],
        price: maps[index]['price'],
        description: maps[index]['description'],
        imagePath: maps[index]['imagePath'],
      );
    });
  }

  static Future<int> updateProduct(ProductSq product) async {
    final db = await instance.database;
    return await db.update(
      'likedP',
      product.toMap(),
    );
  }

  static Future<int> deleteProduct(ProductSq product) async {
    final db = await instance.database;
    return await db.delete(
      'likedP',
      where: 'name = ?',
      whereArgs: [product.name],
    );
  }
}

class ProductSq {
  final String name;
  final String? description;
  final String? imagePath;
  final double price;

  ProductSq({
    this.description,
    this.imagePath,
    required this.name,
    required this.price,
  });

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'price': price,
      'description':description,
      'imagePath':imagePath
      // Added isLiked field to the map
    };
  }
}

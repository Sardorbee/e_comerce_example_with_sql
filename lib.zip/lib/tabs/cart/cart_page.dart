import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get_storage/get_storage.dart';

class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  // bool isVisible = false;
  final box = GetStorage();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView.builder(
          itemCount: 1,
          itemBuilder: (context, index) => Slidable(
            endActionPane: ActionPane(
              motion: const ScrollMotion(),
              children: [
                SlidableAction(
                  flex: 2,
                  onPressed: (context) {
                    setState(() {
                     
                    });
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: Colors.red,
                        content: Text('A product deleted successfully.'),
                      ),
                    );
                  },
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                  icon: Icons.delete,
                  label: 'Delete',
                ),
              ],
            ),
            child: FutureBuilder(builder: )
          ),
        ),
      ),
    );
  }
}


// box.read("ProductImagePath") != null
//                 ? Container(
//                     height: 100,
//                     decoration: BoxDecoration(
//                       color: Colors.blue,
//                       borderRadius: BorderRadius.circular(
//                         20,
//                       ),
//                     ),
//                     padding: EdgeInsets.all(8),
//                     // visible: isVisible,
//                     child: ListTile(
//                       leading: Image.asset(box.read("ProductImagePath")),
//                       title: Text(box.read("ProductName")),
//                       trailing: Text(box.read("ProductPrice").toString()),
//                     ),
//                   )
//                 : Container(
//                     padding: EdgeInsets.all(25),
//                     child: const Center(
//                         child: Text(
//                             style: TextStyle(fontSize: 20),
//                             "You didn't save any product for cart")),
//                   ),
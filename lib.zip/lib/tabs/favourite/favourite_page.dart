import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:neww/sqflite/db.dart';

class FavouritePage extends StatefulWidget {
  const FavouritePage({super.key});

  @override
  State<FavouritePage> createState() => _FavouritePageState();
}

class _FavouritePageState extends State<FavouritePage> {
  List<ProductSq> productList = [];
  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  void fetchProducts() async {
    List<ProductSq> products = await DatabaseHelper.getProducts();
    setState(() {
      productList = products;
    });
  }

  final box = GetStorage();
  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(
          20,
        ),
        child: ListView.builder(
          itemCount: productList.length,
          itemBuilder: (context, index) {
            ProductSq product = productList[index];
            
            return Container(
              padding: const EdgeInsets.all(20),
              height: 100,
              decoration: BoxDecoration(
                color: Colors.blue,
                borderRadius: BorderRadius.circular(
                  20,
                ),
              ),
              child: ListTile(
                title: Text(product.name),
                trailing: TextButton(
                  onPressed: () async {
                    await DatabaseHelper.deleteProduct(product);
                    setState(() {
                      productList.remove(product);
                    });
                  },
                  child: const Text(
                    "Unlike",
                    style: TextStyle(
                      color: Colors.red,
                    ),
                  ),
                ),
              ),
            );
          },
        ));
  }
}

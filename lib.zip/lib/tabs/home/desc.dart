import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';

import 'data/data_list.dart';

// ignore: must_be_immutable
class DescriptionPage extends StatefulWidget {
  Product? datttas;
  DescriptionPage({Key? key, this.datttas}) : super(key: key);

  @override
  State<DescriptionPage> createState() => _DescriptionPageState();
}

class _DescriptionPageState extends State<DescriptionPage> {
  final box = GetStorage();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text("Product Description"),
            IconButton(
              onPressed: () {
                box.write("ProductName", widget.datttas!.name);
                box.write("ProductImagePath", widget.datttas!.imagePath);
                box.write("ProductPrice", widget.datttas!.price);
                box.write("ProductLastPrice", widget.datttas!.lastPrice);
                box.write("ProductDescription", widget.datttas!.description);
              },
              icon: Icon(Icons.save),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: Image.asset(widget.datttas!.imagePath),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    children: [
                      const Text(
                        'Name: ',
                      ),
                      Text(
                        '${widget.datttas!.name} \$',
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text(
                        'Price: ',
                      ),
                      Text(
                        '${widget.datttas!.price} \$',
                        style: const TextStyle(
                          color: Colors.green,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text(
                        'Last Price: ',
                      ),
                      Text(
                        '${widget.datttas!.lastPrice} \$',
                        style: const TextStyle(
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      const Text(
                        'Description: ',
                      ),
                      Text(
                        '${widget.datttas!.description} \$',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:like_button/like_button.dart';
import 'package:neww/sqflite/db.dart';
import '../login/login_page.dart';
import 'data/data_list.dart';
import 'desc.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // bool isliked = false;
  final box = GetStorage();
  List<bool> isLikedList = List.filled(productList.length, true);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            padding: const EdgeInsets.all(8),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 0.75, // Adjust the aspect ratio as needed
            ),
            itemBuilder: (context, index) {
              bool isLiked = isLikedList[index];
              Product product = productList[index];
              return Container(
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.all(
                    Radius.circular(
                      20,
                    ),
                  ),
                ),
                height: 350,
                width: 150,
                child: Stack(
                  children: [
                    InkWell(
                      onTap: () {
                        final productt = ProductSq(
                          name: product.name,
                          price: product.price,
                          description: product.description,
                          imagePath:product.imagePath
                           
                        );
                        DatabaseHelper.insertProduct(productt);

                        // getLogin("LoginName");

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => box.read("IsLoggedIn") == true
                                ? DescriptionPage(
                                    datttas: productList[index],
                                  )
                                : const LoginPage(),
                          ),
                        );
                      },
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.all(12),
                            decoration: const BoxDecoration(
                                borderRadius: BorderRadius.all(
                                  Radius.circular(
                                    20,
                                  ),
                                ),
                                color: Colors.blue),
                            height: 150,
                            width: 170,
                            child: Image.asset(product.imagePath),
                          ),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.blue,
                              borderRadius: BorderRadius.circular(
                                20,
                              ),
                            ),
                            child: Align(
                              alignment: Alignment.topLeft,
                              child: Column(
                                children: [
                                  Text('Name: ${product.name} '),
                                  Row(
                                    children: [
                                      const Text(
                                        'Price: ',
                                      ),
                                      Text(
                                        '${product.price} \$',
                                        style: const TextStyle(
                                          color: Colors.green,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      const Text(
                                        'Last Price: ',
                                      ),
                                      Text(
                                        '${product.lastPrice} \$',
                                        style: const TextStyle(
                                          color: Colors.red,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Text('Description: ${product.description}'),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      right: 0,
                      child: Container(
                        alignment: Alignment.topRight,
                        height: 50,
                        width: 50,
                        child: LikeButton(
                          key: ValueKey(index),
                          size: 28,
                          circleColor: const CircleColor(
                            start: Color(0xff00ddff),
                            end: Color(0xff0099cc),
                          ),
                          bubblesColor: const BubblesColor(
                            dotPrimaryColor: Color(0xff33b5e5),
                            dotSecondaryColor: Color(0xff0099cc),
                          ),
                          likeBuilder: (bool isLiked) {
                            return Icon(
                              Icons.favorite,
                              color: isLiked ? Colors.red : Colors.white,
                              size: 28,
                            );
                          },
                          isLiked: isLiked,
                          // onTap: (isLiked) async {
                          //   final productt = ProductSq(
                          //     name: product.name,
                          //     price: product.price,
                          //   );

                          //   setState(() {
                          //     isLikedList[index] = !isLiked;
                          //   });

                          //   if (isLiked) {
                          //     await DatabaseHelper.insertProduct(productt);
                          //   } else {
                          //     // Handle the case when the like button is unliked
                          //     // You can remove the product from the database or perform any other action
                          //   }
                          // },
                          onTap: (isLiked) async {
                            // Replace with your actual product data
                            final productt = ProductSq(
                              name: product.name,
                              price: product.price,
                            );

                            setState(() {
                              // isLiked = !isLiked;
                              if (isLiked) {
                                DatabaseHelper.insertProduct(productt);
                              }
                              // isLikedList[index] = !isLiked;
                            });
                          },
                        ),
                      ),
                    )
                  ],
                ),
              );
            },
            itemCount: productList.length,
          ),
        ),
      ),
    );
  }
}

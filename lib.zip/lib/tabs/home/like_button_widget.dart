// import 'package:flutter/material.dart';
// import 'package:get_storage/get_storage.dart';
// import 'package:like_button/like_button.dart';
// import 'package:neww/sqflite/db.dart';

// import 'data/data_list.dart';

// // ignore: must_be_immutable
// class LikeButtonWidget extends StatefulWidget {
//   // VoidCallback disliked;
//   final int id;

//   LikeButtonWidget(
//       {super.key,
//       // required this.disliked,
//       // required this.onliked,
//       required this.id});

//   @override
//   // ignore: library_private_types_in_public_api
//   _LikeButtonWidgetState createState() => _LikeButtonWidgetState();
// }

// class _LikeButtonWidgetState extends State<LikeButtonWidget> {
//   final box = GetStorage();
//   bool isLiked = false;

//   @override
//   void initState() {
//     super.initState();
//   }

//   @override
//   Widget build(
//     BuildContext context,
//   ) {
//     return 
//   }
// }
